"""ARIA Insight Agent - upgraded signal, chart, anomaly, prediction and story engine.

Input: Goal Agent processed_data.json
Output: insights.json

New capabilities in this version:
1. automatic chart recommendation + render-ready Chart.js specs,
2. natural-language anomaly detection,
3. easy-word business storytelling,
4. existing time-series forecast support,
5. encoded tabular prediction for mixed tables (numeric + category + dates).
"""

from __future__ import annotations

import json
import logging
import math
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from core.validation import validate_chart_choice
from llm_provider import create_provider
from prediction import PredictionAgent
from prediction.tabular import TabularPredictor
from prescription_agent import PrescriptionAgent

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("aria.insight")

CHART_TEMPLATES_PATH = Path(__file__).resolve().parent / "static" / "chart_templates.json"


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def sanitize_json(obj):
    """Recursively convert non-JSON-safe numpy/pandas/NaN values."""
    if isinstance(obj, dict):
        return {str(k): sanitize_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [sanitize_json(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        obj = float(obj)
    if isinstance(obj, float) and (math.isnan(obj) or math.isinf(obj)):
        return None
    if isinstance(obj, (pd.Timestamp, datetime)):
        return obj.isoformat()
    return obj


def _is_id_like(name: str) -> bool:
    low = str(name).lower().strip()
    return (
        low in {"id", "key", "code", "codeid"}
        or low.endswith("_id")
        or low.endswith("_key")
    )


def _human_name(name: str) -> str:
    return str(name).replace("_", " ").strip()


def _fmt(value: Any) -> str:
    try:
        value = float(value)
        if abs(value) >= 1_000_000:
            return f"{value / 1_000_000:.2f}M"
        if abs(value) >= 1_000:
            return f"{value:,.0f}"
        if abs(value) >= 100:
            return f"{value:,.1f}"
        return f"{value:,.2f}"
    except Exception:
        return str(value)


class InsightAgent:
    def __init__(self, provider=None):
        self.llm = provider or create_provider()
        self.prediction = PredictionAgent()          # existing time-series forecast
        self.encoded_prediction = TabularPredictor() # NEW: encoded mixed-table ML
        self.prescription = PrescriptionAgent(provider=self.llm)
        self._templates = None

    # ------------------------------------------------------------------
    # Loading + column understanding
    # ------------------------------------------------------------------

    def load_processed_data(self, processed_data_path="processed_data.json"):
        with open(processed_data_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _classify_columns(self, df: pd.DataFrame):
        """Classify numeric/category/date columns without treating IDs as measures."""
        if df.empty:
            return [], [], []

        numeric: list[str] = []
        category: list[str] = []
        datetime_cols: list[str] = []

        for col in df.columns:
            series = df[col]
            sample = series.dropna()
            if sample.empty:
                continue

            if pd.api.types.is_numeric_dtype(series):
                numeric.append(col)
                continue

            # Decimal values often arrive as JSON strings.
            coerced = pd.to_numeric(sample, errors="coerce")
            if coerced.notna().mean() >= 0.8:
                numeric.append(col)
                continue

            # Date parse only when the name/content looks date-like.
            low = str(col).lower()
            date_hint = any(k in low for k in ("date", "time", "year", "month", "day", "week", "quarter"))
            text_hint = sample.astype(str).head(25).str.contains(r"[-/:T]", regex=True).mean() >= 0.6
            if date_hint or text_hint:
                parsed = pd.to_datetime(sample, errors="coerce")
                if parsed.notna().mean() >= 0.8:
                    datetime_cols.append(col)
                    continue

            category.append(col)

        return numeric, category, datetime_cols

    def _coerce_columns(self, df, numeric_cols, datetime_cols):
        df = df.copy()
        for col in numeric_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")
        for col in datetime_cols:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col], errors="coerce")
                try:
                    if getattr(df[col].dt, "tz", None) is not None:
                        df[col] = df[col].dt.tz_localize(None)
                except Exception:
                    pass
        return df

    # ------------------------------------------------------------------
    # KPI + trends
    # ------------------------------------------------------------------

    def compute_kpis(self, df, numeric_cols):
        kpis = []
        for col in numeric_cols:
            if _is_id_like(col):
                continue
            s = pd.to_numeric(df[col], errors="coerce")
            valid = s.dropna()
            if valid.empty:
                continue
            kpis.append({
                "column": col,
                "sum": round(float(valid.sum()), 2),
                "mean": round(float(valid.mean()), 2),
                "median": round(float(valid.median()), 2),
                "min": round(float(valid.min()), 2),
                "max": round(float(valid.max()), 2),
                "std": round(float(valid.std()), 2) if len(valid) > 1 else None,
                "count": int(valid.count()),
                "null_count": int(s.isna().sum()),
            })
        return kpis

    def detect_trends(self, df, datetime_cols, numeric_cols):
        trends = []
        measures = [c for c in numeric_cols if not _is_id_like(c)]
        if not datetime_cols or not measures:
            return trends

        dt_col = datetime_cols[0]
        temp = df.dropna(subset=[dt_col]).copy()
        if temp.empty:
            return trends

        for col in measures:
            series = temp.groupby(dt_col)[col].sum().sort_index().dropna()
            if len(series) < 3:
                continue
            values = series.to_numpy(dtype=float)
            x = np.arange(len(values), dtype=float)
            slope = float(np.polyfit(x, values, 1)[0]) if len(values) >= 2 else 0.0
            start = float(values[0])
            end = float(values[-1])
            pct = ((end - start) / abs(start) * 100.0) if start else None
            baseline = max(abs(float(np.mean(values))), 1e-9)
            slope_ratio = slope / baseline
            if slope_ratio > 0.01:
                direction = "increasing"
            elif slope_ratio < -0.01:
                direction = "decreasing"
            else:
                direction = "mostly stable"
            trends.append({
                "dimension": dt_col,
                "column": col,
                "direction": direction,
                "pct_change": round(float(pct), 2) if pct is not None and math.isfinite(pct) else None,
                "start_value": round(start, 2),
                "latest_value": round(end, 2),
                "natural_language": self._trend_sentence(col, direction, pct, start, end),
            })
        return trends

    def _trend_sentence(self, col, direction, pct, start, end):
        name = _human_name(col)
        if pct is None:
            return f"{name} is {direction} over the available time period."
        return (
            f"{name} is {direction}. It moved from about {_fmt(start)} to {_fmt(end)}, "
            f"a change of {pct:+.1f}% across the available period."
        )

    # ------------------------------------------------------------------
    # Natural-language anomaly detection
    # ------------------------------------------------------------------

    def detect_anomalies(self, df, numeric_cols, category_cols=None, datetime_cols=None):
        """Use a robust IQR rule, with z-score fallback, and explain each signal in plain English."""
        anomalies = []
        category_cols = category_cols or []
        datetime_cols = datetime_cols or []
        context_cols = (datetime_cols[:1] + category_cols[:2])

        for col in numeric_cols:
            if _is_id_like(col):
                continue
            s = pd.to_numeric(df[col], errors="coerce")
            valid = s.dropna()
            if len(valid) < 5:
                continue

            median = float(valid.median())
            q1 = float(valid.quantile(0.25))
            q3 = float(valid.quantile(0.75))
            iqr = q3 - q1
            mean = float(valid.mean())
            std = float(valid.std()) if len(valid) > 1 else 0.0

            if iqr > 0:
                low_bound = q1 - 1.5 * iqr
                high_bound = q3 + 1.5 * iqr
                severe_low = q1 - 3.0 * iqr
                severe_high = q3 + 3.0 * iqr
                mask = (s < low_bound) | (s > high_bound)
                method = "IQR"
            elif std > 0 and math.isfinite(std):
                low_bound = mean - 2.5 * std
                high_bound = mean + 2.5 * std
                severe_low = mean - 3.5 * std
                severe_high = mean + 3.5 * std
                mask = (s < low_bound) | (s > high_bound)
                method = "z-score fallback"
            else:
                continue

            for idx in s[mask].index.tolist():
                value = float(s.loc[idx])
                direction = "high" if value > high_bound else "low"
                severity = "high" if (value > severe_high or value < severe_low) else "medium"
                pct_from_typical = None
                if abs(median) > 1e-12:
                    pct_from_typical = (value - median) / abs(median) * 100.0

                context = []
                for c in context_cols:
                    if c in df.columns:
                        v = df.loc[idx, c]
                        if pd.notna(v):
                            context.append(f"{_human_name(c)}={v}")
                context_text = ", ".join(context)
                sentence = self._anomaly_sentence(
                    col, value, median, direction, severity, pct_from_typical, context_text
                )
                anomalies.append({
                    "column": col,
                    "row": int(idx) if isinstance(idx, (int, np.integer)) else str(idx),
                    "value": round(value, 2),
                    "direction": direction,
                    "severity": severity,
                    "typical_value": round(median, 2),
                    "expected_range": [round(float(low_bound), 2), round(float(high_bound), 2)],
                    "difference_pct_from_typical": round(float(pct_from_typical), 2) if pct_from_typical is not None else None,
                    "method": method,
                    "context": context_text or None,
                    "natural_language": sentence,
                })

        # Biggest deviations first, then cap payload size.
        anomalies.sort(
            key=lambda a: (0 if a["severity"] == "high" else 1,
                           -abs(a.get("difference_pct_from_typical") or 0)),
        )
        return anomalies[:30]

    def _anomaly_sentence(self, col, value, median, direction, severity, pct, context):
        name = _human_name(col)
        where = f" for {context}" if context else ""
        if pct is not None:
            comparison = f"about {abs(pct):.0f}% {'above' if pct > 0 else 'below'} its usual level"
        else:
            comparison = f"far from its usual level of about {_fmt(median)}"
        importance = "This is a strong unusual signal" if severity == "high" else "This value is unusual"
        return f"{importance}: {name} is {_fmt(value)}{where}, {comparison}. It is worth checking what caused it."

    def summarize_anomalies(self, anomalies):
        if not anomalies:
            return "No strong unusual values were found in the main business measures."
        high = sum(1 for a in anomalies if a.get("severity") == "high")
        lead = anomalies[0].get("natural_language", "")
        if high:
            return f"ARIA found {len(anomalies)} unusual values, including {high} strong signals. {lead}"
        return f"ARIA found {len(anomalies)} unusual values. {lead}"

    # ------------------------------------------------------------------
    # Automatic chart recommendation + dashboard specs
    # ------------------------------------------------------------------

    def _load_chart_templates(self):
        if self._templates is None:
            try:
                self._templates = json.loads(CHART_TEMPLATES_PATH.read_text(encoding="utf-8")).get("templates", {})
            except Exception:
                self._templates = {}
        return self._templates

    @staticmethod
    def _deep_merge(base, extra):
        if not isinstance(base, dict) or not isinstance(extra, dict):
            return extra if extra is not None else base
        out = dict(base)
        for key, value in extra.items():
            if isinstance(value, dict) and isinstance(out.get(key), dict):
                out[key] = InsightAgent._deep_merge(out[key], value)
            else:
                out[key] = value
        return out

    def _chart_template(self, chart_id):
        templates = self._load_chart_templates()
        return templates.get(chart_id, {}).get("config", {})

    def _make_chart(self, chart_id, title, reason, x, y, labels, datasets, priority=50, extra_options=None):
        cfg = self._chart_template(chart_id)
        options = self._deep_merge(dict(cfg.get("options", {})), extra_options or {})
        options.setdefault("responsive", True)
        options.setdefault("maintainAspectRatio", False)
        chart_type = cfg.get("type", "bar")
        return {
            "chart_type": chart_id,
            "title": title,
            "why_this_chart": reason,
            "priority": int(priority),
            "x": x,
            "y": y,
            "labels": labels,
            "datasets": datasets,
            "template": cfg,
            "config": {
                "type": chart_type,
                "data": {"labels": labels, "datasets": datasets},
                "options": options,
            },
        }

    def build_dashboard_spec(self, df, numeric_cols, category_cols, datetime_cols, chart_suggestions=None):
        """Choose charts from the data shape automatically; LLM does not decide the chart type."""
        specs = []
        palette = ["#38bdf8", "#34d399", "#fbbf24", "#f87171", "#a78bfa", "#f472b6"]
        measures = [c for c in numeric_cols if not _is_id_like(c)]

        def bar_ds(label, values, color=palette[0]):
            return {"label": label, "data": values, "backgroundColor": color, "borderColor": color, "borderWidth": 1}

        def line_ds(label, values, color=palette[0]):
            return {
                "label": label, "data": values, "borderColor": color,
                "backgroundColor": color + "33", "borderWidth": 2,
                "pointRadius": 3, "tension": 0.3, "fill": False,
            }

        # A) Time present -> line chart is the primary recommendation.
        if datetime_cols and measures:
            dt = datetime_cols[0]
            temp = df.dropna(subset=[dt]).copy().sort_values(dt)
            if not temp.empty:
                primary = measures[0]
                grouped = temp.groupby(dt)[primary].sum().sort_index()
                labels = [pd.Timestamp(v).strftime("%Y-%m-%d") for v in grouped.index]
                values = [float(v) for v in grouped.values]
                specs.append(self._make_chart(
                    "line",
                    f"{_human_name(primary)} over time",
                    "A line chart is best because the x-axis is time and the main question is how the value changes from period to period.",
                    dt, primary, labels, [line_ds(primary, values)], priority=100,
                ))

                if len(measures) >= 2:
                    cols = measures[:3]
                    common_index = temp.groupby(dt)[cols[0]].sum().sort_index().index
                    datasets = []
                    for i, c in enumerate(cols):
                        g = temp.groupby(dt)[c].sum().reindex(common_index).fillna(0)
                        datasets.append(line_ds(c, [float(v) for v in g.values], palette[i % len(palette)]))
                    specs.append(self._make_chart(
                        "line",
                        f"{' vs '.join(_human_name(c) for c in cols)} over time",
                        "Multiple lines make it easy to compare how the main measures move together across the same time periods.",
                        dt, "+".join(cols),
                        [pd.Timestamp(v).strftime("%Y-%m-%d") for v in common_index], datasets, priority=82,
                    ))

        # B) Category + measure -> ranked bar/horizontal bar.
        if category_cols and measures:
            for dim_idx, dim in enumerate(category_cols[:2]):
                primary = measures[0]
                grouped = df.groupby(dim, dropna=False)[primary].sum().sort_values(ascending=False).head(10)
                if grouped.empty:
                    continue
                labels = [str(v) for v in grouped.index]
                values = [float(v) for v in grouped.values]
                long_labels = max((len(v) for v in labels), default=0) > 14
                chart_id = "bar_horizontal" if long_labels or len(labels) >= 8 else "bar"
                reason = (
                    "A horizontal bar chart is best because there are several categories or long labels, so ranking remains readable."
                    if chart_id == "bar_horizontal"
                    else "A bar chart is best because the data compares one numeric measure across separate categories."
                )
                specs.append(self._make_chart(
                    chart_id,
                    f"{_human_name(primary)} by {_human_name(dim)}",
                    reason,
                    dim, primary, labels, [bar_ds(primary, values)], priority=90 - dim_idx * 5,
                ))

                # Only use pie when it is genuinely a small part-to-whole view.
                card = int(df[dim].nunique(dropna=True))
                total = float(np.nansum(values))
                if 2 <= card <= 5 and total > 0 and np.all(np.asarray(values) >= 0):
                    pie_data = [{"label": primary, "data": values, "backgroundColor": palette[:len(values)]}]
                    specs.append(self._make_chart(
                        "pie",
                        f"{_human_name(primary)} share by {_human_name(dim)}",
                        "A pie chart works here because there are only a few categories and they form meaningful shares of one total.",
                        dim, primary, labels, pie_data, priority=65,
                    ))

        # C) Numeric-only shapes.
        if measures and not datetime_cols and not category_cols:
            if len(measures) == 1:
                col = measures[0]
                s = pd.to_numeric(df[col], errors="coerce").dropna()
                if s.nunique() > 1:
                    counts, edges = np.histogram(s.values, bins=min(10, max(5, int(np.sqrt(len(s))))))
                    labels = [f"{edges[i]:.1f}-{edges[i + 1]:.1f}" for i in range(len(counts))]
                    specs.append(self._make_chart(
                        "histogram",
                        f"Distribution of {_human_name(col)}",
                        "A histogram is best because there is one numeric measure and the useful question is how its values are distributed.",
                        col, "count", labels, [bar_ds("count", [int(v) for v in counts])], priority=90,
                    ))
            else:
                x, y = measures[:2]
                sample = df[[x, y]].dropna().head(100)
                pts = [{"x": float(a), "y": float(b)} for a, b in zip(sample[x], sample[y])]
                specs.append(self._make_chart(
                    "scatter",
                    f"{_human_name(y)} vs {_human_name(x)}",
                    "A scatter chart is best because both axes are numeric and it can reveal whether the two measures move together.",
                    x, y, [], [{"label": y, "data": pts, "backgroundColor": palette[0]}], priority=90,
                ))

        # D) Category-only -> count chart.
        if category_cols and not measures and not datetime_cols:
            dim = category_cols[0]
            counts = df[dim].value_counts(dropna=False).head(10)
            labels = [str(v) for v in counts.index]
            chart_id = "bar_horizontal" if len(labels) >= 8 or max((len(v) for v in labels), default=0) > 14 else "bar"
            specs.append(self._make_chart(
                chart_id,
                f"Record count by {_human_name(dim)}",
                "A bar chart is best because the table contains categories and the useful comparison is how many records fall into each group.",
                dim, "count", labels, [bar_ds("count", [int(v) for v in counts.values])], priority=90,
            ))

        # E) KPI cards are useful whenever measures exist.
        if measures:
            specs.append({
                "chart_type": "kpi_card",
                "title": "Key performance indicators",
                "why_this_chart": "KPI cards give the main numbers at a glance before the user explores detailed charts.",
                "priority": 95,
                "x": None,
                "y": None,
                "labels": [],
                "datasets": [],
                "template": self._chart_template("kpi_card"),
                "config": {"type": "kpi_card", "data": {"labels": [], "datasets": []}, "options": {}},
                "data": self.compute_kpis(df, measures),
            })

        # Highest-priority charts first. Keep dashboard useful rather than noisy.
        specs.sort(key=lambda s: s.get("priority", 0), reverse=True)
        return specs[:8]

    def chart_recommendation(self, dashboard):
        visual = [d for d in dashboard if d.get("chart_type") != "kpi_card"]
        if not visual:
            return {
                "primary_chart_type": None,
                "title": None,
                "reason": "The current result does not contain enough compatible columns for a meaningful chart.",
                "alternatives": [],
            }
        primary = visual[0]
        return {
            "primary_chart_type": primary.get("chart_type"),
            "title": primary.get("title"),
            "reason": primary.get("why_this_chart"),
            "alternatives": [
                {"chart_type": v.get("chart_type"), "title": v.get("title"), "reason": v.get("why_this_chart")}
                for v in visual[1:4]
            ],
        }

    # ------------------------------------------------------------------
    # Hypotheses
    # ------------------------------------------------------------------

    def generate_hypotheses(self, df, numeric_cols, category_cols, datetime_cols, kpis, anomalies, trends=None):
        hyps = []
        measures = [c for c in numeric_cols if not _is_id_like(c)]

        def add(text, basis, confidence, score):
            hyps.append({"hypothesis": text, "basis": basis, "confidence": confidence, "score": float(score)})

        for col in measures[:3]:
            total = float(pd.to_numeric(df[col], errors="coerce").sum())
            if total == 0:
                continue
            for dim in category_cols[:2]:
                try:
                    grp = df.groupby(dim)[col].sum().sort_values(ascending=False)
                except Exception:
                    continue
                if grp.empty:
                    continue
                top_label = grp.index[0]
                top_share = float(grp.iloc[0]) / total * 100.0
                if top_share >= 20:
                    add(
                        f"{top_label} is the leading {_human_name(dim)} group, contributing about {top_share:.0f}% of {_human_name(col)}.",
                        f"Compared each {_human_name(dim)} group's share of total {_human_name(col)}.",
                        "high" if top_share >= 50 else "medium",
                        10 + top_share / 10,
                    )

        for t in (trends or [])[:2]:
            add(t["natural_language"], "Compared the first and latest periods and checked the overall direction.", "medium", 8)

        if anomalies:
            add(
                anomalies[0]["natural_language"],
                "Checked the main measures for values outside their usual range.",
                "high" if anomalies[0].get("severity") == "high" else "medium",
                9,
            )

        if kpis:
            lead = kpis[0]
            add(
                f"The average {_human_name(lead['column'])} is about {_fmt(lead['mean'])}, with values ranging from {_fmt(lead['min'])} to {_fmt(lead['max'])}.",
                "Summarised the main numeric measure.",
                "high",
                5,
            )

        hyps.sort(key=lambda h: h["score"], reverse=True)
        return hyps[:5], sum(h["score"] for h in hyps[:5])

    # ------------------------------------------------------------------
    # Easy-word storytelling
    # ------------------------------------------------------------------

    def generate_business_story(self, processed_data, kpis, trends, anomalies, hypotheses,
                                predictions=None, encoded_prediction=None):
        base = self._narrative_story(
            processed_data, kpis, trends, anomalies, hypotheses, predictions, encoded_prediction
        )

        context = {
            "goal": processed_data.get("user_goal"),
            "kpis": kpis[:4],
            "trends": trends[:2],
            "anomalies": [a.get("natural_language") for a in anomalies[:3]],
            "hypotheses": [h.get("hypothesis") for h in hypotheses[:3]],
        }
        if predictions and predictions.get("valid"):
            context["forecast"] = {
                "column": predictions.get("column"),
                "projected_pct_change": predictions.get("projected_pct_change"),
                "accuracy_pct": predictions.get("accuracy_pct"),
            }
        if encoded_prediction and encoded_prediction.get("valid"):
            context["encoded_prediction"] = encoded_prediction.get("natural_language")

        prompt = f"""
You are ARIA's retail/sales Insight Agent. Rewrite the draft below for a busy,
non-technical manager.

DRAFT:
{base}

FACTS:
{json.dumps(context, indent=2, default=str)}

Rules:
- Use very easy English and short sentences.
- Start with the most important finding.
- Explain what changed, where, and why it matters when the data supports it.
- Do not use words such as z-score, standard deviation, coefficient, regression,
  feature engineering, encoder, p-value, or statistical significance.
- Do not invent causes. Say "may" or "worth checking" when the cause is unknown.
- Maximum 180 words. No markdown. No bullets. No JSON.
"""
        try:
            polished = self.llm.chat(
                "story",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.25,
                num_predict=300,
                timeout=35,
            )
            polished = (polished or "").strip()
            if 40 <= len(polished) <= 1400:
                return self._plain_english_story(polished)
        except Exception as exc:
            log.warning("Story LLM failed; deterministic story used: %s", exc)
        return self._plain_english_story(base)

    def _plain_english_story(self, text):
        replacements = [
            (r"\bstandard deviations?\b", "usual range"),
            (r"\bz[- ]?score\b", "unusual-value score"),
            (r"\bcoefficient of variation\b", "amount of change"),
            (r"\bdispersion\b", "spread"),
            (r"\bregression model\b", "prediction model"),
            (r"\bone-hot encoding\b", "category handling"),
            (r"\bfeature engineering\b", "data preparation"),
        ]
        out = text
        for pattern, replacement in replacements:
            out = re.sub(pattern, replacement, out, flags=re.IGNORECASE)
        return out.strip()

    def _narrative_story(self, processed_data, kpis, trends, anomalies, hypotheses,
                         predictions=None, encoded_prediction=None):
        parts = []
        goal = str(processed_data.get("user_goal") or "").strip()
        rows = processed_data.get("row_count") or len(processed_data.get("data") or [])

        if hypotheses:
            parts.append(f"Main finding: {hypotheses[0]['hypothesis']}")
        elif goal:
            parts.append(f"ARIA analysed {rows} rows for: {goal}.")
        else:
            parts.append(f"ARIA analysed {rows} rows.")

        if trends:
            parts.append(trends[0]["natural_language"])
        if len(hypotheses) > 1:
            parts.append(hypotheses[1]["hypothesis"])
        if anomalies:
            parts.append(anomalies[0]["natural_language"])
        if predictions and predictions.get("valid") and predictions.get("points"):
            parts.append(
                f"For the next {predictions.get('horizon')} {predictions.get('period') or 'periods'}, "
                f"{_human_name(predictions.get('column'))} is expected to change by about "
                f"{predictions.get('projected_pct_change')}%. The forecast passed its accuracy check."
            )
        if encoded_prediction and encoded_prediction.get("valid"):
            parts.append(encoded_prediction.get("natural_language", ""))
        if not anomalies:
            parts.append("No strong unusual values were found in the main measures.")
        return " ".join(p for p in parts if p)

    # ------------------------------------------------------------------
    # Main pipeline
    # ------------------------------------------------------------------

    def analyze(self, processed_data_path="processed_data.json", output_path="insights.json"):
        warnings = []
        try:
            processed_data = self.load_processed_data(processed_data_path)
            rows = processed_data.get("data", [])
            df = pd.DataFrame(rows)
        except Exception as exc:
            processed_data = {}
            df = pd.DataFrame()
            warnings.append(f"load_processed_data: {exc}")

        print(
            f"Insight Agent analysing {processed_data_path} "
            f"({processed_data.get('row_count', len(df))} rows)..."
        )

        def safe(name, fn, default):
            try:
                return fn()
            except Exception as exc:
                log.warning("Insight step '%s' failed: %s", name, exc)
                warnings.append(f"{name}: {exc}")
                return default

        numeric_cols, category_cols, datetime_cols = safe(
            "classify_columns", lambda: self._classify_columns(df), ([], [], [])
        )
        df = safe(
            "coerce_columns", lambda: self._coerce_columns(df, numeric_cols, datetime_cols), df
        )

        kpis = safe("compute_kpis", lambda: self.compute_kpis(df, numeric_cols), [])
        trends = safe("detect_trends", lambda: self.detect_trends(df, datetime_cols, numeric_cols), [])
        anomalies = safe(
            "detect_anomalies",
            lambda: self.detect_anomalies(df, numeric_cols, category_cols, datetime_cols),
            [],
        )
        anomaly_summary = self.summarize_anomalies(anomalies)

        dashboard = safe(
            "build_dashboard_spec",
            lambda: self.build_dashboard_spec(df, numeric_cols, category_cols, datetime_cols),
            [],
        )
        chart_choice = self.chart_recommendation(dashboard)

        hypotheses, ranking_score = safe(
            "generate_hypotheses",
            lambda: self.generate_hypotheses(
                df, numeric_cols, category_cols, datetime_cols, kpis, anomalies, trends
            ),
            ([], 0.0),
        )

        # 1) Existing mathematically validated time-series forecast.
        predictions = safe(
            "time_series_prediction",
            lambda: self.prediction.forecast(
                processed_data,
                datetime_col=datetime_cols[0] if datetime_cols else None,
            ) if numeric_cols else None,
            None,
        )

        # 2) NEW encoded table prediction. Categorical features are one-hot encoded,
        # numeric values are imputed/scaled, and date columns become calendar features.
        encoded_prediction = safe(
            "encoded_tabular_prediction",
            lambda: self.encoded_prediction.predict(processed_data),
            None,
        )

        prescriptions = safe(
            "prescription",
            lambda: self.prescription.prescribe(
                processed_data, kpis, trends, anomalies, hypotheses, predictions
            ),
            None,
        )

        story = safe(
            "business_story",
            lambda: self.generate_business_story(
                processed_data, kpis, trends, anomalies, hypotheses,
                predictions, encoded_prediction,
            ),
            None,
        ) or self._narrative_story(
            processed_data, kpis, trends, anomalies, hypotheses, predictions, encoded_prediction
        )

        insights = {
            "generated_at": datetime.now().isoformat(),
            "source_processed_data": processed_data_path,
            "user_goal": processed_data.get("user_goal", "Unknown goal"),
            "summary": {
                "rows": int(len(df)),
                "columns": list(df.columns),
                "numeric_columns": numeric_cols,
                "categorical_columns": category_cols,
                "datetime_columns": datetime_cols,
            },
            "kpis": kpis,
            "trends": trends,
            "anomalies": anomalies,
            "anomaly_summary": anomaly_summary,
            "hypotheses": hypotheses,
            "hypothesis_ranking_score": round(float(ranking_score), 2),
            "predictions": predictions,
            "encoded_prediction": encoded_prediction,
            "prescriptions": prescriptions,
            "chart_recommendation": chart_choice,
            "dashboard": dashboard,
            "business_story": story,
            "warning": "; ".join(warnings) if warnings else None,
        }

        output = sanitize_json(insights)
        Path(output_path).write_text(json.dumps(output, indent=2, default=str), encoding="utf-8")
        print(f"Insight Agent done! Saved to {output_path}")
        return output_path


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python insight_agent.py processed_data.json")
        raise SystemExit(1)
    InsightAgent().analyze(sys.argv[1])
