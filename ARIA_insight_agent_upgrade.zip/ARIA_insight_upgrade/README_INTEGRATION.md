# ARIA Insight Agent upgrade

Replace/add these files in the current ARIA repository:

- `insight_agent.py` -> replace existing root file
- `prediction/tabular.py` -> new file
- `requirements.txt` -> add `scikit-learn` (this package includes the full current list)
- `tests/test_encoded_prediction.py` -> new test
- `tests/test_insight_natural_language.py` -> new test

Do **not** move prediction/encoding into the Schema Agent. The correct flow remains:

`Schema Agent -> Goal Agent -> processed_data.json -> Insight Agent -> insights.json`

The Goal Agent first resolves tables/joins and returns a processed result table. The
new encoded predictor then prepares that result for ML:

- numeric columns: median imputation + standard scaling
- categorical columns: most-frequent imputation + OneHotEncoder(handle_unknown="ignore")
- date columns: year/month/day/day-of-week features
- IDs/keys: dropped from model features
- high-cardinality free text: dropped to avoid one-hot explosion

## New output keys

`chart_recommendation`
: tells the frontend which chart is primary and why.

`anomalies[*].natural_language`
: explains each anomaly in manager-friendly words.

`anomaly_summary`
: one natural-language anomaly summary.

`encoded_prediction`
: supervised ML prediction result with preprocessing/encoding metadata,
  metrics, feature importance, and sample predictions.

The old `predictions` key is preserved for the existing time-series PredictionAgent,
so existing UI code does not need to break.

## Run

```bash
pip install -r requirements.txt
pytest -q tests/test_encoded_prediction.py tests/test_insight_natural_language.py
python insight_agent.py processed_data.json
```

## Expected output fragment

```json
{
  "chart_recommendation": {
    "primary_chart_type": "bar",
    "title": "sales by category",
    "reason": "A bar chart is best because the data compares one numeric measure across separate categories."
  },
  "anomaly_summary": "ARIA found 1 unusual value...",
  "encoded_prediction": {
    "mode": "encoded_tabular",
    "target": "sales",
    "encoding": {
      "categorical": {
        "steps": ["most-frequent imputation", "one-hot encoding"]
      }
    }
  }
}
```
