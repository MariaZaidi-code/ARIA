import pandas as pd

# This test imports InsightAgent only in the real ARIA repo where llm_provider,
# prescription_agent and core.validation are present.
from insight_agent import InsightAgent


class DummyProvider:
    def chat(self, *args, **kwargs):
        raise RuntimeError("offline in unit test")


def test_anomaly_contains_plain_language():
    agent = InsightAgent(provider=DummyProvider())
    df = pd.DataFrame({
        "region": ["A", "A", "A", "B", "B", "B", "C", "C", "C", "C"],
        "sales": [100, 101, 99, 102, 98, 100, 101, 99, 100, 1000],
    })
    anomalies = agent.detect_anomalies(df, ["sales"], ["region"], [])
    assert anomalies
    assert anomalies[0]["natural_language"]
    assert "worth checking" in anomalies[0]["natural_language"].lower()


def test_chart_recommends_bar_for_category_measure():
    agent = InsightAgent(provider=DummyProvider())
    df = pd.DataFrame({"category": ["A", "B", "C"], "sales": [10, 30, 20]})
    dashboard = agent.build_dashboard_spec(df, ["sales"], ["category"], [])
    rec = agent.chart_recommendation(dashboard)
    assert rec["primary_chart_type"] in {"bar", "bar_horizontal"}
    assert rec["reason"]
